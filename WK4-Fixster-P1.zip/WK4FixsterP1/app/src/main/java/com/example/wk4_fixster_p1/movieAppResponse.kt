package com.example.wk4_fixster_p1

data class MovieApiResponse(
    val results: List<Movie>
    )

    data class Movie(
        val title: String,
        val overview: String,
        val poster_path: String
    )

}
