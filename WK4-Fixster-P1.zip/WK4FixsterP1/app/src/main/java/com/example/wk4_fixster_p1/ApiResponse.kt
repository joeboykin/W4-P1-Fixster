package com.example.wk4_fixster_p1

class ApiResponse {
    data class ApiResponse(
        val message: String,
        val data: List<User>
    )

}