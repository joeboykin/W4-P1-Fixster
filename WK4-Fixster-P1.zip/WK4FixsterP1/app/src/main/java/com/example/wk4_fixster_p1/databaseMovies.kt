package com.example.wk4_fixster_p1

class databaseMovies(context: Context) : SQLiteOpenHelper(context, "mydatabase.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        // Create your database tables and columns here
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Handle database upgrades here
    }
}

}