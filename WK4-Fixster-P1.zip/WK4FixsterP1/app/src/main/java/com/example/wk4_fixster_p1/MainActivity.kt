package com.example.wk4_fixster_p1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
    val retrofit = Retrofit.Builder()

//        .baseUrl("https://api.themoviedb.org/3/")
        .baseUrl("https://developers.themoviedb.org/3/movies/get-now-playing")
        .addConverterFactory(GsonConverterFactory.create())
        .client(OkHttpClient.Builder().build())
        .build()

    val apiService = retrofit.create(ApiService::class.java)

}