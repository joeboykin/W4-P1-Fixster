package com.example.wk4_fixster_p1

private val Any.id: Any
    get() {}
private val Any.size: Int
    get() {}

class MyDao {
    fun getAllItems() {

    }

}

open class BaseAdapter {

    open fun getItem(position: Int): Any {
        TODO("Not yet implemented")
    }
}

private operator fun Any.get(position: Int) {

}

private fun Any.toLong(): Long {

}

class MyAdapter(context: Context, dao: MyDao) : BaseAdapter() {
    class Context {

    }

    private val items = dao.getAllItems()

    fun getCount(): Int = items.size

    override fun getItem(position: Int): Any = items[position]

    fun getItemId(position: Int): Long = items[position].id.toLong()

    class View {

    }

    class ViewGroup {

    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view = convertView ?: LayoutInflater.from(parent?.context).
}