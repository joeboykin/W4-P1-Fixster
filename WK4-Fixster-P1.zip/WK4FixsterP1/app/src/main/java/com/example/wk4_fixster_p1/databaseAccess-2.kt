package com.example.wk4_fixster_p1

class MyDatabaseHelper(context: Context) : SQLiteOpenHelper(context, "mydatabase.db", null, 1) {

        override fun onCreate(db: SQLiteDatabase) {
            // Create your database tables and columns here
        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
            // Handle database upgrades here
        }
    }
class MyDaoImpl(context: Context) : MyDao {

    private val dbHelper = MyDatabaseHelper(context)

    override fun getAllItems(): List<MyItem> {
        val db = dbHelper.readableDatabase
        val cursor = db.query("mytable", null, null, null, null, null, null)
        val items = mutableListOf<MyItem>()
        with(cursor) {
            while (moveToNext()) {
                val item = MyItem(
                    id = getInt(getColumnIndexOrThrow("_id")),
                    name = getString(getColumnIndexOrThrow("name")),
                    description = getString(getColumnIndexOrThrow("description"))
                )
                items.add(item)
            }
        }
        cursor.close()
        return items
    }

    override fun addItem(item: MyItem) {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put("name", item.name)
            put("description", item.description)
        }
        db.insert("mytable", null, values)
    }

    override fun updateItem(item: MyItem) {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put("name", item.name)
            put("description", item.description)
        }
        val selection = "_id = ?"
        val selectionArgs = arrayOf(item.id.toString())
        db.update("mytable", values, selection, selectionArgs)
    }

    override fun deleteItem(item: MyItem) {
        val db = dbHelper.writableDatabase
        val selection = "_id = ?"
        val selectionArgs = arrayOf(item.id.toString())
        db.delete("mytable", selection, selectionArgs)
    }
}

}
